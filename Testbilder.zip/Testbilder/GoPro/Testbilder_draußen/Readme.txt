Bildvorverarbeitung ist schlecht!
Einstellungen ->ca. Coeff = 175 (Bei Standart 70 ist die Plattform �berbelichtet!)